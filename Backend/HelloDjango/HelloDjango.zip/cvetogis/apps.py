from django.apps import AppConfig


class CvetogisConfig(AppConfig):
    name = 'cvetogis'
